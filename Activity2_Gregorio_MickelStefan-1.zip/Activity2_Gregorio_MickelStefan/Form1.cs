﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity2_Gregorio_MickelStefan
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnShowResult_Click(object sender, EventArgs e)
        {
            string Gender = String.Empty;
            string Hobbies = String.Empty;
            string City = String.Empty;
            string CivilStatus = String.Empty;

            if (rbnMale.Checked == true)
            {
                Gender = "Male";
            }
            else if (rbnFemale.Checked == true)
            {
                Gender = "Female";
            }

            if (chkBasketBall.Checked == true)
            {
                Hobbies = Hobbies + "/t" + "Basketball" + Environment.NewLine;
            }
            if (chkSwimming.Checked == true)
            {
                Hobbies = Hobbies + "/t" + "Swimming" + Environment.NewLine;
            }
            if (chkWatchingTv.Checked == true)
            {
                Hobbies = Hobbies + "WatchingTV" + Environment.NewLine;
            }

            if(chkBasketBall.Checked == false && chkSwimming.Checked == false && chkWatchingTv.Checked == false)
            {
                Hobbies = Hobbies + "\t" + "none" + Environment.NewLine;
            }

            City = cboCity.Text;
            CivilStatus = lstCivilStatus.Text;

            MessageBox.Show("Full name: " + txtFirstName.Text + " " + txtLastName.Text + Environment.NewLine
                + "Age: " + txtAge.Text + Environment.NewLine
                + "Gender: " + Gender + Environment.NewLine
                + "Contact No: " + txtContactNo.Text + Environment.NewLine
                + "City: " + City + Environment.NewLine
                + "Civil Status: " + CivilStatus + Environment.NewLine
                + "Hobbies :" + Hobbies, "Personal Info Summary");
        }
    }
}
